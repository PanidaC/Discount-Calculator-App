package th.ac.su.ict.discountcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val price = findViewById<EditText>(R.id.price)
        val discount = findViewById<EditText>(R.id.discount)
        val tax = findViewById<CheckBox>(R.id.tax)
        val btcal = findViewById<Button>(R.id.btcal)
        val pricetal = findViewById<TextView>(R.id.pricetal)

        btcal.setOnClickListener() {
            var p: Double = price.text.toString().toDouble()
            var d: Int = discount.text.toString().toInt()
            if (tax.isChecked) {
                var dis = p * d / 100;
                var total = p - dis;
                var t = total * 7 / 100;
                var totaltax = total + t;
                pricetal.text = totaltax.toString()
            }else{
                var dis = p * d / 100;
                var total = p - dis;
                pricetal.text = total.toString()
            }
        }
    }
}